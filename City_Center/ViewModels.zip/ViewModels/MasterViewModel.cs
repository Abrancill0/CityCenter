﻿using System;
namespace City_Center.ViewModels
{
    public class MasterViewModel
    {
       
    }
}
